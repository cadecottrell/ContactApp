package com.example.contact;

import android.content.Context;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Collections;


// Written by Cade Cottrell for CS4301.002, Contact Phase 1 Assignment
// netid: cac160030

public class FileIO {


    //Variables that are responsible for proper file identification

    private String filePath = "cac160030.txt";
    Context mContext;
    File file;

    //Max 85 length of a record
    private int charsPerLine = 85;


    //Constructor
    public FileIO(Context mContext) {
        this.mContext = mContext;
        file = new File(mContext.getFilesDir(), filePath);
    }

    //Writes a new record at the bottom of the Random Access File.
    public void writeFullRecord(String record)
    {
        try
        {
            RandomAccessFile randomAccessFile = new RandomAccessFile(file,"rw");
            long lineLocation = randomAccessFile.length();

            randomAccessFile.seek(lineLocation);
            randomAccessFile.write(record.getBytes());
            randomAccessFile.writeBytes(System.getProperty("line.separator"));
            randomAccessFile.close();

        }
        catch(Exception ex)
        {
            System.out.println("Something went wrong with the writing FULL record");
            ex.printStackTrace();
        }

    }


    //Grabs all records in the Random Access File and returns an ArrayList of Strings
    public ArrayList<String> getAllContacts(Context context)
    {
        ArrayList<String> contactObjects = new ArrayList<>();
        int bytesPerLine = charsPerLine + 1;

        try
        {
            RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rw");

            if(randomAccessFile.length() != 0)
            {
                String currentLine = "";

                for(int i = 0; i < randomAccessFile.length(); i++)
                {
                    randomAccessFile.seek(bytesPerLine*i);
                    currentLine = randomAccessFile.readLine();
                    if(currentLine != null)
                    {
                        contactObjects.add(currentLine);
                    }
                    else
                    {
                        break;
                    }
                }
                Collections.sort(contactObjects);
                return contactObjects;
            }
            else
            {
                return contactObjects;
            }
        }
        catch(Exception ex)
        {
            System.out.println("SOMETHING WENT WRONG IN READING DATA");
        }

        return contactObjects;
    }


    //Modifies a given record, by overwritting its location
    protected void modifyLineFromRecord(int position, String newRecord)
    {
        int bytesPerLine = charsPerLine + 1;

        try
        {
            RandomAccessFile randomAccessFile = new RandomAccessFile(file, "rw");
            randomAccessFile.seek(bytesPerLine*(position));


            randomAccessFile.write(newRecord.getBytes());
            randomAccessFile.writeBytes(System.getProperty("line.separator"));
            randomAccessFile.close();

        }
        catch(Exception ex)
        {
            System.out.println("SOMETHING WENT WRONG IN MODIFY LINE");
            ex.printStackTrace();
        }

    }


    //Goes over file and skips the line we do not want. We create a new file then rename it to the previous
    protected void deleteLineFromRecord(int position)
    {
        File oldFile = file;
        File newFile = new File(mContext.getFilesDir(),"tempR.txt");

        String currentLine = "";

        try
        {
            FileWriter fw = new FileWriter(newFile, true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter pw = new PrintWriter(bw);

            FileReader fr = new FileReader(oldFile);
            BufferedReader br = new BufferedReader(fr);

            int i = 0;
            while((currentLine = br.readLine()) != null)
            {
                if(i != position)
                {
                    pw.println(currentLine);
                }
                i++;
            }

            pw.flush();
            pw.close();
            fr.close();
            br.close();
            bw.close();
            fw.close();

            oldFile.delete();
            File temp = new File(mContext.getFilesDir(), filePath);
            newFile.renameTo(temp);

        }
        catch(Exception ex)
        {
            System.out.println("DELETION WENT WRONG");
            ex.printStackTrace();
        }

    }


}
