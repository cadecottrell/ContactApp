package com.example.contact;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

// Written by Cade Cottrell for CS4301.002, Contact Phase 1 Assignment
// netid: cac160030


//This is the Modify/Delete Fragment. It brings up the normal "Add contact fragment" but has two buttons
//And has the previous record's information in the edittexts

public class ModifyDeleteFragment extends Fragment {

    //Variables
    private EditText birthDate;
    private EditText dateMet;
    private EditText firstName;
    private EditText lastName;
    private EditText phoneNumber;

    private Button modifyButton;
    private Button deleteButton;


    //onCreat
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.modify_contact_fragment, container, false);

        //Find ids
        birthDate = view.findViewById(R.id.birthCalendarModify);
        dateMet = view.findViewById(R.id.firstMetModifyCalendar);
        firstName = view.findViewById(R.id.firstNameEditModify);
        lastName = view.findViewById(R.id.lastNameEditModify);
        phoneNumber = view.findViewById(R.id.phoneNumberEditModify);

        modifyButton = view.findViewById(R.id.Modify);
        deleteButton = view.findViewById(R.id.Delete);


        //Display text on EditTexts
        setupEditTexts();


        birthDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((Contact)getActivity()).setIsBirthDate(true);
                ((Contact)getActivity()).setViewPager(1);
            }
        });


        dateMet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((Contact)getActivity()).setIsBirthDate(false);
                ((Contact)getActivity()).setViewPager(1);
            }
        });


        //Modify button to modify record.
        modifyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if( ((Contact)getActivity()).allFilled(lastName, firstName, phoneNumber, dateMet) && ((Contact)getActivity()).notOverSized(lastName,firstName, phoneNumber, birthDate, dateMet))
                {
                    Toast.makeText(getActivity(), "Saving Modified Contact", Toast.LENGTH_LONG).show();

                    String record = ((Contact)getActivity()).setupSaveData(lastName,firstName,phoneNumber,birthDate,dateMet);

                    ((Contact)getActivity()).completeModifyDeleteActivity(record, "Modify",((Contact)getActivity()).getLineNumber());

                }
                else
                {
                    Toast.makeText(getActivity(), "Make sure everything is filled out.", Toast.LENGTH_LONG).show();
                }
            }
        });

        //delete button to delete record
        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getActivity(), "Deleting Contact", Toast.LENGTH_LONG).show();
                ((Contact)getActivity()).completeModifyDeleteActivity("", "Delete",((Contact)getActivity()).getLineNumber());
            }
        });



        return view;
    }



    //Sets up editTexts
    protected void setupEditTexts()
    {
        String record = ((Contact)getActivity()).getContactString();

        String[] recordList = record.split(":");

        lastName.setText(recordList[0]);
        firstName.setText(recordList[1]);
        phoneNumber.setText(recordList[2]);
        birthDate.setText(recordList[3]);
        dateMet.setText(recordList[4]);

    }

    protected void addDate(String date)
    {
        if( ((Contact)getActivity()).getIsBirthDate() )
        {
            birthDate.setText(date);
        }
        else
        {
            dateMet.setText(date);
        }
    }

}
